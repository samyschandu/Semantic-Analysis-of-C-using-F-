void main()
{
  int count;
  
  int x;
  cin >> x;
  cout << x;
  x = 123*5;

  int xyz;
  xyz = 12345;

  real zyx;
  zyx = 12345.987654321;

  

  
  
  int y;
  cin >> y;

  real var;

  if (true)
    if (false)
      if (x<y)
        if (x>y)
          if (123<=12345)
            if (0>=0)
              if (100!=200)
                if (1==2)
                  x = y;
                else
                  y = 1-2;
              else
                y = x*y;
            else
              count = count/2;
          else
            x=x^y;
        else
          var=1.9+var;
      else
        y=x;

  real r;
  r = 0.2;
  r = 0.234;
  int counter;
  counter = 0;
  r = 0.;
  real r2;
  r2 = 1234.;
  if (r2 < 1234.5678)
    ;
  else if (12345.6 > r)
    ;
  else
    ;
        
  cout << "done";
  cout << endl;
  real lastVar;
  int  oops;
}